# cassini_upyp.uvisdata

This module provides the main classes used to load, process, calibrate, and analyze Cassini/UVIS observations.

## Main observation classes

```{autoclass} cassini_upyp.uvisdata.UVIS_Observation
:members:
:show-inheritance:
```

```{autoclass} cassini_upyp.uvisdata.UVIS_Bin
:members:
:show-inheritance:
```

## Instrument description

```{autoclass} cassini_upyp.uvisdata.Instrument
:members:
:show-inheritance:
```

## Helper classes

The following classes are utility containers used internally by the module.
They are documented here for completeness but are not intended as primary user entry points.

```{autoclass} cassini_upyp.uvisdata.AttrDict
:members:
:show-inheritance:
```