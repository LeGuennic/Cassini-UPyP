# Cassini-UPyP

Cassini-UPyP is a research-oriented Python toolbox for working with Cassini/UVIS data.

```{toctree}
:maxdepth: 2

installation
configuration
api/index
```